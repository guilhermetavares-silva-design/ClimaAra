"""Texto exibido no botão 'Sobre' da interface."""

CONTATO_EMAIL = "guilherme.tavares-silva@unesp.br"

ABOUT_TEXT = f"""ClimaAra — Validador de Acurácia Climática (GEE x Observado)
Instituto de Geociências e Ciências Exatas - UNESP Rio Claro

O QUE ESTE PROGRAMA FAZ
Extrai uma ou mais variáveis climáticas de coleções do Google Earth Engine
(precipitação, temperatura, umidade, evapotranspiração, radiação, pressão,
vento, etc.) para uma área de interesse, e compara cada uma com os dados
observados equivalentes de uma estação, calculando métricas de acurácia
(R², RMSE, NSE, KGE, PBIAS) e gerando gráficos de regressão, ciclo sazonal,
resíduos mensais e PBIAS anual — uma validação separada para CADA variável
que você tiver nos dados observados.

A extração é sempre entregue em base MENSAL: quando a coleção de origem é
diária (BR-DWGD v2025 diário, CHIRPS), os valores diários são agregados por
mês automaticamente (soma para variáveis acumulativas como precipitação e
evapotranspiração; média para variáveis de estado como temperatura,
umidade, vento e radiação). Se sua planilha observada tiver dados diários,
eles também são agregados por mês do mesmo jeito antes da comparação.

IMPORTANTE — formato dos dados observados: mesmo com essa agregação
automática, o correto é sempre comparar dado com a MESMA resolução
temporal de origem: se você tem uma estação com registros diários, use os
dados diários da estação (a agregação mensal automática cuida do resto);
se só tem totais/médias mensais já fechados da estação, use-os como estão.
Não misture uma planilha mensal "reconstruída" a partir de outra fonte com
uma coleção diária do Earth Engine (ou vice-versa) — isso pode mascarar
erros e comprometer as métricas de acurácia.

PASSO A PASSO
1. Área: selecione um shapefile (.shp) ou GeoJSON (.geojson) com o
   polígono da área de interesse. Se for .shp, mantenha os arquivos
   .dbf/.shx/.prj na mesma pasta — eles são lidos automaticamente.
   Shapefiles em qualquer sistema de coordenadas (ex.: SIRGAS 2000/UTM) são
   reprojetados automaticamente para WGS84. Se o arquivo não tiver um
   .prj, o programa assume que já está em WGS84 (EPSG:4326).

2. Variáveis (GEE): informe o ID do seu projeto do Earth Engine (o mesmo
   usado para autenticar — na primeira execução, uma aba do navegador vai
   abrir pedindo login na sua conta Google), o ano inicial e o ano final
   do período que você quer analisar, e marque, na lista agrupada por
   coleção, TODAS as variáveis que você quer extrair para a área
   selecionada (pode marcar quantas quiser, de coleções diferentes ao
   mesmo tempo). Clique em "Extrair variáveis selecionadas". Ao terminar,
   você já pode baixar essa extração bruta em .xlsx (botão "Baixar dados
   extraídos"), mesmo sem ter uma planilha observada ainda. Nem toda
   coleção cobre o período inteiro que você pedir — se faltar dado em
   algum mês, a extração avisa quais variáveis ficaram com cobertura
   incompleta.

3. Dados observados: selecione uma planilha .xlsx com os dados de
   referência (veja o formato abaixo). O programa detecta as colunas de
   variáveis presentes e sugere, para cada uma, a variável extraída do GEE
   correspondente (você pode trocar a sugestão ou marcar "não comparar"
   para qualquer coluna). A validação de acurácia é feita SÓ para as
   colunas que você mapear — se sua planilha só tiver precipitação, só
   precipitação é validada; se tiver precipitação, temperatura e vento,
   as três são validadas separadamente.

4. Clique em "Executar validação". A extração no Earth Engine pode levar
   alguns minutos dependendo do número de variáveis, do tamanho da área e
   do período.

5. Na aba "Resultados", escolha uma variável na lista à esquerda para ver
   suas métricas e os 4 gráficos. Use os botões de exportação para salvar
   os dados de uma variável (ou de todas de uma vez) em .xlsx, e cada
   gráfico em .png.

FORMATO DA PLANILHA DE DADOS OBSERVADOS
O formato mais simples e recomendado é: uma coluna de data e uma coluna
por variável observada, com o nome da variável no cabeçalho. A data pode
ser mensal (uma linha por mês) ou diária (uma linha por dia — nesse caso
os valores são agregados por mês automaticamente antes da comparação).
Células em branco são permitidas (a variável simplesmente não é usada
naquele mês/dia). Exemplo:

    Data       | Precipitacao | TMedia | TMax | TMin | Umidade | VelocidadeVento
    -----------+--------------+--------+------+------+---------+-----------------
    2020-01    | 210.4        | 24.3   | 30.1 | 18.2 | 78      | 1.4
    2020-02    | 180.2        | 24.8   | 30.5 | 19.0 | 75      | 1.6
    2020-03    | 95.7         |        | 29.2 | 18.5 | 80      |
    ...

(datas completas como 15/01/2020 ou 2020-01-15 também são aceitas, para
dados diários). O nome de cada coluna é livre — o programa reconhece
palavras comuns (chuva/precipitação, tmax/máxima, tmin/mínima,
tmédia/temperatura, umidade, vento, direção, pressão, orvalho, ETP/ETo)
para sugerir automaticamente o pareamento com a variável do GEE certa,
mas você sempre confirma ou corrige isso na aba 3 antes de validar.

O formato antigo "aba por ano" do CEAPLA (uma aba por ano, coluna "DIA",
linha "Total" com JAN..DEZ) continua funcionando, mas só é interpretado
como precipitação mensal.

COLEÇÕES DISPONÍVEIS
- BR-DWGD v2025 diário e BR-DWGD v2025 mensal (ee-alexandrexavier):
  precipitação, evapotranspiração (FAO56), umidade relativa, radiação
  solar, temperatura máxima/mínima e velocidade do vento a 2m. Cobertura
  1961-2025, território brasileiro.
- CHIRPS (diário): precipitação.
A lista completa vem do arquivo collections_config.json — novas coleções
podem ser adicionadas nesse arquivo sem precisar alterar o programa.

CITAÇÃO DAS FONTES
Na aba 2, ao lado de cada variável, há um botão "Citação (ABNT)" que copia
para a área de transferência a referência bibliográfica da fonte daquela
coleção (Xavier et al., 2022, para o BR-DWGD; Funk et al., 2015, para o
CHIRPS), pronta para colar na sua lista de referências.

DÚVIDAS
Escreva para {CONTATO_EMAIL}
"""
