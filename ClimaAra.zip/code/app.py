"""Interface gráfica (Tkinter) do ClimaAra (Validador de Acurácia Climática).

Fluxo: escolher uma área (shapefile/GeoJSON local) -> marcar uma ou mais
variáveis de coleções do Google Earth Engine e extraí-las (com opção de
baixar a extração bruta em .xlsx) -> importar dados observados (.xlsx) e
associar cada coluna observada à variável extraída correspondente ->
executar a validação -> conferir métricas/gráficos de cada variável ->
exportar.
"""

import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import ttk, filedialog, messagebox, scrolledtext

from PIL import Image, ImageTk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import about_text
import collections_config
import export_utils
import gee_service
import metrics
import observed_data
import plotting
import worker

ASSETS_DIR = Path(__file__).parent / "assets"
NAO_COMPARAR = "(não comparar)"

APP_NOME = "ClimaAra"
APP_VERSAO = "2.0"
APP_CITACAO_ABNT = (
    "TAVARES, G.; SILVA, C. R. Software para extração e validação de dados "
    "climatológicos: ClimaAra. Versão 2.0. Rio Claro: Departamento de "
    "Geografia e Planejamento Ambiental, IGCE, UNESP, 2026. DOI: "
    "10.5281/zenodo.22096666. Disponível em: "
    "https://doi.org/10.5281/zenodo.22096666."
)

COR_PRIMARIA = "#0aa3e0"
COR_PRIMARIA_ESCURA = "#0682b3"
COR_FUNDO = "#f4f6f8"
COR_TEXTO = "#1a2733"

FIGURAS_INFO = [
    ("regressao", "Regressão", plotting.build_regression_fig),
    ("ciclo", "Ciclo sazonal", plotting.build_cycle_fig),
    ("residuos", "Resíduos", plotting.build_residuals_fig),
    ("pbias", "PBIAS anual", plotting.build_pbias_fig),
]


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title(f"{APP_NOME} — IGCE/UNESP Rio Claro")
        self.geometry("1150x800")
        self.minsize(1000, 700)

        self._logo_refs = []

        self.area_path = None
        self.area_info = None
        self.area_mode_var = tk.StringVar(value="single")
        self.area_id_var = tk.StringVar()
        self.area_auto_id_var = tk.BooleanVar(value=False)

        self.extracted_df = None
        self.extracted_cfgs = []

        self.observed_path = None
        self.observed_df = None
        self.observed_format = None
        self.observed_columns = []
        self.observed_is_daily = False
        self.mapeamento_vars = {}

        self.resultados = []
        self.resultado_atual = None
        self.dados = None
        self.metricas = None
        self.figuras = {}
        self.canvas_por_figura = {}

        try:
            self.collections = collections_config.load_collections()
        except collections_config.CollectionConfigError as exc:
            self.collections = []
            messagebox.showerror("Configuração de coleções", str(exc))

        self._configurar_estilo()
        self._montar_cabecalho()
        self._montar_barra_superior()
        self._montar_rodape()
        self._montar_abas()

    # ------------------------------------------------------------ estilo

    def _configurar_estilo(self):
        self.configure(background=COR_FUNDO)

        estilo = ttk.Style(self)
        try:
            estilo.theme_use("clam")
        except tk.TclError:
            pass

        estilo.configure(".", background=COR_FUNDO, foreground=COR_TEXTO, font=("Segoe UI", 10))
        estilo.configure("TFrame", background=COR_FUNDO)
        estilo.configure("TLabel", background=COR_FUNDO, foreground=COR_TEXTO)
        estilo.configure("TCheckbutton", background=COR_FUNDO, foreground=COR_TEXTO)
        estilo.configure("TSeparator", background=COR_FUNDO)

        estilo.configure("TNotebook", background=COR_FUNDO, borderwidth=0)
        estilo.configure("TNotebook.Tab", padding=(14, 8), font=("Segoe UI", 10))
        estilo.map(
            "TNotebook.Tab",
            background=[("selected", COR_PRIMARIA)],
            foreground=[("selected", "white")],
        )

        estilo.configure("Header.TFrame", background="white")
        estilo.configure("Header.TLabel", background="white")
        estilo.configure("Titulo.TLabel", background="white", foreground=COR_TEXTO, font=("Segoe UI", 16, "bold"))
        estilo.configure("Subtitulo.TLabel", background="white", foreground="#5b6b78", font=("Segoe UI", 9))
        estilo.configure("Grupo.TLabel", font=("Segoe UI", 10, "bold"), foreground=COR_PRIMARIA_ESCURA)
        estilo.configure("Aviso.TLabel", background=COR_FUNDO, foreground="#5b6b78", font=("Segoe UI", 9))

        estilo.configure("TButton", padding=(10, 5))
        estilo.configure("Accent.TButton", background=COR_PRIMARIA, foreground="white",
                          padding=(12, 6), font=("Segoe UI", 10, "bold"))
        estilo.map("Accent.TButton", background=[("active", COR_PRIMARIA_ESCURA)])

        estilo.configure(
            "Info.TButton", background=COR_FUNDO, foreground=COR_PRIMARIA,
            padding=(0, 0), borderwidth=0, relief="flat", font=("Segoe UI", 10, "bold"),
        )
        estilo.map(
            "Info.TButton",
            foreground=[("active", COR_PRIMARIA_ESCURA)],
            background=[("active", COR_FUNDO)],
        )

    # ------------------------------------------------------------ layout

    def _carregar_logo(self, nome_arquivo, altura):
        caminho = ASSETS_DIR / nome_arquivo
        if not caminho.exists():
            return None
        try:
            imagem = Image.open(caminho)
            escala = altura / imagem.height
            imagem = imagem.resize((max(1, int(imagem.width * escala)), altura), Image.LANCZOS)
            foto = ImageTk.PhotoImage(imagem)
        except Exception:
            return None
        self._logo_refs.append(foto)
        return foto

    def _montar_cabecalho(self):
        cabecalho = ttk.Frame(self, style="Header.TFrame", padding=(16, 10))
        cabecalho.pack(side=tk.TOP, fill=tk.X)

        frame_titulo = ttk.Frame(cabecalho, style="Header.TFrame")
        frame_titulo.pack(side=tk.LEFT)
        ttk.Label(frame_titulo, text=APP_NOME, style="Titulo.TLabel").pack(anchor="w")
        ttk.Label(
            frame_titulo,
            text="Extração e validação de variáveis climáticas do Google Earth Engine",
            style="Subtitulo.TLabel",
        ).pack(anchor="w")

        frame_logos = ttk.Frame(cabecalho, style="Header.TFrame")
        frame_logos.pack(side=tk.RIGHT)

        logo_unesp = self._carregar_logo("unesp_logo.png", 44)
        if logo_unesp:
            ttk.Label(frame_logos, image=logo_unesp, style="Header.TLabel").pack(side=tk.LEFT, padx=(0, 14))

        logo_igce = self._carregar_logo("igce_logo.png", 52)
        if logo_igce:
            ttk.Label(frame_logos, image=logo_igce, style="Header.TLabel").pack(side=tk.LEFT)

    def _montar_barra_superior(self):
        barra = ttk.Frame(self, padding=(16, 8))
        barra.pack(side=tk.TOP, fill=tk.X)

        self.botao_executar = ttk.Button(
            barra, text="Executar validação", style="Accent.TButton", command=self.on_executar
        )
        self.botao_executar.pack(side=tk.LEFT)

        ttk.Button(barra, text="Sobre", command=self.mostrar_sobre).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(barra, text="Fale comigo por e-mail", command=self.abrir_email).pack(
            side=tk.LEFT, padx=(8, 0)
        )
        ttk.Button(
            barra, text="ⓘ Como citar",
            command=lambda: self._mostrar_citacao(f"Como citar o {APP_NOME}", APP_CITACAO_ABNT),
        ).pack(side=tk.LEFT, padx=(8, 0))

        self.status_var = tk.StringVar(value="Pronto.")
        ttk.Label(barra, textvariable=self.status_var).pack(side=tk.LEFT, padx=16)

        self.progressbar = ttk.Progressbar(barra, mode="indeterminate", length=160)
        self.progressbar.pack(side=tk.RIGHT)

    def _montar_rodape(self):
        rodape = ttk.Frame(self, padding=(16, 4))
        rodape.pack(side=tk.BOTTOM, fill=tk.X)

        ttk.Label(rodape, text=f"{APP_NOME} v{APP_VERSAO}", style="Aviso.TLabel").pack(side=tk.LEFT)

    def _montar_abas(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        self.aba_area = ttk.Frame(self.notebook, padding=12)
        self.aba_variavel = ttk.Frame(self.notebook, padding=12)
        self.aba_observado = ttk.Frame(self.notebook, padding=12)
        self.aba_resultados = ttk.Frame(self.notebook, padding=12)

        self.notebook.add(self.aba_area, text="1. Área")
        self.notebook.add(self.aba_variavel, text="2. Variáveis (GEE)")
        self.notebook.add(self.aba_observado, text="3. Dados observados")
        self.notebook.add(self.aba_resultados, text="4. Resultados")

        self._montar_aba_area()
        self._montar_aba_variavel()
        self._montar_aba_observado()
        self._montar_aba_resultados()

    def _montar_aba_area(self):
        aba = self.aba_area

        ttk.Label(
            aba,
            text="Selecione o shapefile (.shp) ou GeoJSON (.geojson) da área de interesse.",
        ).pack(anchor="w")

        ttk.Button(
            aba, text="Selecionar shapefile/GeoJSON", command=self.selecionar_area
        ).pack(anchor="w", pady=8)

        self.label_area = ttk.Label(aba, text="Nenhum arquivo selecionado.")
        self.label_area.pack(anchor="w")

        self.frame_multiplas_feicoes = ttk.LabelFrame(
            aba, text="Feições da área", padding=10
        )
        self.frame_multiplas_feicoes.pack(anchor="w", fill=tk.X, pady=(14, 0))

        ttk.Radiobutton(
            self.frame_multiplas_feicoes, text="O arquivo contém uma única feição",
            variable=self.area_mode_var, value="single", command=self._atualizar_controles_feicoes,
        ).pack(anchor="w")
        ttk.Radiobutton(
            self.frame_multiplas_feicoes, text="O arquivo contém mais de uma feição",
            variable=self.area_mode_var, value="multiple", command=self._atualizar_controles_feicoes,
        ).pack(anchor="w", pady=(4, 0))

        self.frame_id_feicao = ttk.Frame(self.frame_multiplas_feicoes, padding=(20, 8, 0, 0))
        self.frame_id_feicao.pack(anchor="w", fill=tk.X)
        ttk.Label(self.frame_id_feicao, text="Campo que identifica cada feição:").grid(row=0, column=0, sticky="w")
        self.combo_id_feicao = ttk.Combobox(
            self.frame_id_feicao, textvariable=self.area_id_var, state="disabled", width=35
        )
        self.combo_id_feicao.grid(row=0, column=1, sticky="w", padx=(8, 0))
        self.check_auto_id = ttk.Checkbutton(
            self.frame_id_feicao,
            text="Não há campo ID: criar IDs sequenciais (0, 1, 2, ...)",
            variable=self.area_auto_id_var, command=self._atualizar_controles_feicoes,
            state="disabled",
        )
        self.check_auto_id.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self.label_feicoes = ttk.Label(
            self.frame_id_feicao,
            text="Selecione um arquivo para verificar suas feições e campos de identificação.",
            style="Aviso.TLabel", wraplength=700, justify="left",
        )
        self.label_feicoes.grid(row=2, column=0, columnspan=2, sticky="w", pady=(6, 0))

    def _criar_area_scrollavel(self, parent):
        canvas = tk.Canvas(parent, borderwidth=0, highlightthickness=0, background=COR_FUNDO)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        frame_interno = ttk.Frame(canvas)

        frame_interno.bind(
            "<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=frame_interno, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        return frame_interno

    def _montar_aba_variavel(self):
        aba = self.aba_variavel

        ttk.Label(aba, text="ID do projeto do Google Earth Engine:").pack(anchor="w")
        self.projeto_var = tk.StringVar()
        ttk.Entry(aba, textvariable=self.projeto_var, width=50).pack(anchor="w", pady=(0, 12))

        frame_periodo = ttk.Frame(aba)
        frame_periodo.pack(anchor="w", pady=(0, 12))

        ttk.Label(frame_periodo, text="Ano inicial:").pack(side=tk.LEFT)
        self.ano_inicial_var = tk.StringVar()
        ttk.Entry(frame_periodo, textvariable=self.ano_inicial_var, width=8).pack(
            side=tk.LEFT, padx=(4, 16)
        )

        ttk.Label(frame_periodo, text="Ano final:").pack(side=tk.LEFT)
        self.ano_final_var = tk.StringVar()
        ttk.Entry(frame_periodo, textvariable=self.ano_final_var, width=8).pack(
            side=tk.LEFT, padx=(4, 0)
        )

        ttk.Label(
            aba, text="Marque as variáveis que deseja extrair para a área selecionada:"
        ).pack(anchor="w")

        frame_lista_container = ttk.Frame(aba)
        frame_lista_container.pack(fill=tk.BOTH, expand=True, pady=(4, 8))
        frame_lista = self._criar_area_scrollavel(frame_lista_container)

        self.variavel_vars = {}
        grupos = collections_config.group_collections(self.collections)
        for grupo, cfgs in grupos.items():
            linha_grupo = ttk.Frame(frame_lista)
            linha_grupo.pack(anchor="w", fill=tk.X, pady=(10, 2))

            ttk.Label(linha_grupo, text=grupo, style="Grupo.TLabel").pack(side=tk.LEFT)

            citacao_grupo = next((c.get("citation_abnt") for c in cfgs if c.get("citation_abnt")), None)
            if citacao_grupo:
                ttk.Button(
                    linha_grupo, text="ⓘ", style="Info.TButton", width=2,
                    command=lambda g=grupo, c=citacao_grupo: self._mostrar_citacao(g, c),
                ).pack(side=tk.LEFT, padx=(6, 0))

            for cfg in cfgs:
                var = tk.BooleanVar(value=False)
                self.variavel_vars[cfg["id"]] = var
                texto = f"{cfg['display_name']}  ({cfg.get('unit', '-')})"
                ttk.Checkbutton(frame_lista, text=texto, variable=var).pack(anchor="w", padx=(12, 0))

        barra_acoes = ttk.Frame(aba)
        barra_acoes.pack(fill=tk.X, pady=(8, 0))

        self.botao_extrair = ttk.Button(
            barra_acoes, text="Extrair variáveis selecionadas do Earth Engine",
            style="Accent.TButton", command=self.on_extrair_variaveis,
        )
        self.botao_extrair.pack(side=tk.LEFT)

        self.botao_baixar_extraido = ttk.Button(
            barra_acoes, text="Baixar dados extraídos (.xlsx)",
            command=self.baixar_extraido, state="disabled",
        )
        self.botao_baixar_extraido.pack(side=tk.LEFT, padx=(8, 0))

        self.label_extracao_status = ttk.Label(aba, text="Nenhuma extração realizada ainda.")
        self.label_extracao_status.pack(anchor="w", pady=(8, 0))

    def _montar_aba_observado(self):
        aba = self.aba_observado

        ttk.Label(
            aba,
            text=(
                "Selecione a planilha .xlsx com os dados observados "
                "(veja o botão 'Sobre' para o formato esperado)."
            ),
        ).pack(anchor="w")

        ttk.Label(
            aba,
            text=(
                "Atenção: a planilha observada precisa estar na mesma resolução "
                "temporal da variável extraída que você vai comparar com ela — "
                "dado diário com dado diário, dado mensal com dado mensal. Não "
                "misture (ex.: não compare uma planilha mensal com uma coleção "
                "diária, nem o contrário)."
            ),
            wraplength=760, justify="left", style="Aviso.TLabel",
        ).pack(anchor="w", pady=(4, 0))

        ttk.Button(
            aba, text="Selecionar planilha .xlsx", command=self.selecionar_observado
        ).pack(anchor="w", pady=8)

        self.label_observado = ttk.Label(aba, text="Nenhuma planilha selecionada.", justify="left")
        self.label_observado.pack(anchor="w")

        ttk.Separator(aba, orient="horizontal").pack(fill=tk.X, pady=12)
        ttk.Label(
            aba, text="Associe cada coluna observada à variável extraída correspondente:",
            style="Grupo.TLabel",
        ).pack(anchor="w")

        self.frame_mapeamento = ttk.Frame(aba, padding=(0, 8))
        self.frame_mapeamento.pack(fill=tk.BOTH, expand=True)
        ttk.Label(
            self.frame_mapeamento,
            text="Extraia variáveis na aba 2 e selecione uma planilha para configurar o mapeamento.",
        ).pack(anchor="w")

    def _montar_aba_resultados(self):
        aba = self.aba_resultados

        topo = ttk.Frame(aba)
        topo.pack(fill=tk.X)

        self.botao_exportar_dados = ttk.Button(
            topo, text="Exportar variável atual (.xlsx)", command=self.exportar_dados,
            state="disabled",
        )
        self.botao_exportar_dados.pack(side=tk.LEFT)

        self.botao_exportar_tudo = ttk.Button(
            topo, text="Exportar todas as variáveis (.xlsx)", command=self.exportar_tudo,
            state="disabled",
        )
        self.botao_exportar_tudo.pack(side=tk.LEFT, padx=(8, 0))

        corpo = ttk.Frame(aba, padding=(0, 10))
        corpo.pack(fill=tk.BOTH, expand=True)

        frame_lista = ttk.Frame(corpo, width=230)
        frame_lista.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 14))
        frame_lista.pack_propagate(False)

        ttk.Label(frame_lista, text="Variáveis validadas", style="Grupo.TLabel").pack(anchor="w")
        ttk.Label(
            frame_lista,
            text=(
                "Só aparece aqui a variável extraída que foi associada a uma "
                "coluna observada na aba 3. Para baixar tudo que foi extraído "
                "(mesmo sem dado observado), use 'Baixar dados extraídos' na aba 2."
            ),
            wraplength=210, justify="left", style="Aviso.TLabel",
        ).pack(anchor="w", pady=(2, 6))
        self.lista_resultados = tk.Listbox(
            frame_lista, exportselection=False, activestyle="none",
            background="white", relief="flat", highlightthickness=1,
            highlightbackground="#d5dbe0", font=("Segoe UI", 10),
        )
        self.lista_resultados.pack(fill=tk.BOTH, expand=True, pady=(6, 0))
        self.lista_resultados.bind("<<ListboxSelect>>", self._on_selecionar_resultado)

        frame_detalhe = ttk.Frame(corpo)
        frame_detalhe.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.frame_metricas = ttk.Frame(frame_detalhe, padding=(0, 0, 0, 12))
        self.frame_metricas.pack(fill=tk.X)
        self.label_metricas_vazio = ttk.Label(
            self.frame_metricas, text="Execute a validação para ver as métricas."
        )
        self.label_metricas_vazio.pack(anchor="w")

        self.sub_notebook = ttk.Notebook(frame_detalhe)
        self.sub_notebook.pack(fill=tk.BOTH, expand=True)

        self.frames_figuras = {}
        self.botoes_exportar_png = {}

        for chave, titulo, _builder in FIGURAS_INFO:
            frame = ttk.Frame(self.sub_notebook, padding=8)
            self.sub_notebook.add(frame, text=titulo)

            frame_canvas = ttk.Frame(frame)
            frame_canvas.pack(fill=tk.BOTH, expand=True)

            botao = ttk.Button(
                frame, text="Exportar PNG",
                command=lambda c=chave: self.exportar_grafico(c),
                state="disabled",
            )
            botao.pack(anchor="e", pady=(6, 0))

            self.frames_figuras[chave] = frame_canvas
            self.botoes_exportar_png[chave] = botao

    # ------------------------------------------------------------- ações

    def abrir_email(self):
        assunto = "Duvida - Validador de Acuracia Climatica"
        webbrowser.open(f"mailto:{about_text.CONTATO_EMAIL}?subject={assunto.replace(' ', '%20')}")

    def _mostrar_citacao(self, grupo, texto):
        janela = tk.Toplevel(self)
        janela.title("Citação (ABNT)")
        janela.configure(background=COR_FUNDO)
        janela.resizable(False, False)

        corpo = ttk.Frame(janela, padding=16)
        corpo.pack(fill=tk.BOTH, expand=True)

        ttk.Label(corpo, text=grupo, style="Grupo.TLabel").pack(anchor="w", pady=(0, 8))

        caixa_texto = tk.Text(
            corpo, wrap=tk.WORD, width=70, height=5,
            background="white", relief="flat", highlightthickness=1,
            highlightbackground="#d5dbe0", font=("Segoe UI", 10), padx=8, pady=8,
        )
        caixa_texto.insert("1.0", texto)
        caixa_texto.config(state="disabled")
        caixa_texto.pack(fill=tk.BOTH, expand=True)

        barra = ttk.Frame(corpo, padding=(0, 10, 0, 0))
        barra.pack(fill=tk.X)

        def copiar():
            self.clipboard_clear()
            self.clipboard_append(texto)
            self.status_var.set(f"Citação (ABNT) de '{grupo}' copiada para a área de transferência.")

        ttk.Button(barra, text="Copiar citação", style="Accent.TButton", command=copiar).pack(side=tk.LEFT)
        ttk.Button(barra, text="Fechar", command=janela.destroy).pack(side=tk.LEFT, padx=(8, 0))

    def selecionar_area(self):
        caminho = filedialog.askopenfilename(
            title="Selecione o shapefile ou GeoJSON",
            filetypes=[("Shapefile ou GeoJSON", "*.shp *.geojson *.json"), ("Todos os arquivos", "*.*")],
        )
        if not caminho:
            return

        try:
            info = gee_service.inspect_area_file(caminho)
        except gee_service.GeeServiceError as exc:
            messagebox.showerror("Área de interesse", str(exc))
            return

        self.area_path = caminho
        self.area_info = info
        n_feicoes = info["feature_count"]
        self.label_area.config(text=f"Selecionado: {caminho}\nFeições encontradas: {n_feicoes}.")
        self.combo_id_feicao.config(values=info["id_fields"])
        self.area_id_var.set(info["id_fields"][0] if info["id_fields"] else "")
        self.area_auto_id_var.set(n_feicoes > 1 and not info["id_fields"])
        self.area_mode_var.set("multiple" if n_feicoes > 1 else "single")
        self._atualizar_controles_feicoes()

    def _atualizar_controles_feicoes(self):
        multiplas = self.area_mode_var.get() == "multiple"
        possui_campos = bool(self.area_info and self.area_info["id_fields"])
        auto = self.area_auto_id_var.get()

        self.combo_id_feicao.config(state="readonly" if multiplas and possui_campos and not auto else "disabled")
        self.check_auto_id.config(state="normal" if multiplas else "disabled")
        if not multiplas:
            self.label_feicoes.config(text="A extração usará a área inteira como uma única feição.")
        elif auto:
            self.label_feicoes.config(text="Serão criados IDs sequenciais de 0 até o número da última feição.")
        elif possui_campos:
            self.label_feicoes.config(text="Escolha o campo com valores únicos para identificar as feições na extração.")
        else:
            self.area_auto_id_var.set(True)
            self.label_feicoes.config(text="Nenhum campo com valores únicos foi encontrado; IDs sequenciais serão usados.")

    def selecionar_observado(self):
        caminho = filedialog.askopenfilename(
            title="Selecione a planilha de dados observados",
            filetypes=[("Planilha Excel", "*.xlsx"), ("Todos os arquivos", "*.*")],
        )
        if not caminho:
            return

        try:
            df, formato, colunas, is_daily = observed_data.load_observed(caminho)
        except observed_data.ObservedDataError as exc:
            messagebox.showerror("Dados observados", str(exc))
            return
        except Exception as exc:
            messagebox.showerror("Dados observados", f"Erro ao ler a planilha: {exc}")
            return

        self.observed_path = caminho
        self.observed_df = df
        self.observed_format = formato
        self.observed_columns = colunas
        self.observed_is_daily = is_daily

        granularidade = "diária (agregada por mês na validação)" if is_daily else "mensal"
        self.label_observado.config(
            text=(
                f"Selecionado: {caminho}\n"
                f"Formato: {formato} | Granularidade: {granularidade}\n"
                f"Variáveis encontradas: {', '.join(colunas)}"
            )
        )

        self._atualizar_mapeamento()

    def _atualizar_mapeamento(self):
        for widget in self.frame_mapeamento.winfo_children():
            widget.destroy()
        self.mapeamento_vars = {}

        if self.observed_df is None:
            ttk.Label(self.frame_mapeamento, text="Selecione uma planilha observada acima.").pack(anchor="w")
            return

        if not self.extracted_cfgs:
            ttk.Label(
                self.frame_mapeamento,
                text="Extraia variáveis na aba 2 antes de configurar o mapeamento.",
            ).pack(anchor="w")
            return

        sugestoes = observed_data.suggest_variable_mapping(self.observed_columns, self.extracted_cfgs)
        by_id = {cfg["id"]: cfg for cfg in self.extracted_cfgs}
        opcoes = [NAO_COMPARAR] + [cfg["display_name"] for cfg in self.extracted_cfgs]

        ttk.Label(self.frame_mapeamento, text="Coluna observada", style="Grupo.TLabel").grid(
            row=0, column=0, sticky="w", padx=(0, 12), pady=(0, 4)
        )
        ttk.Label(self.frame_mapeamento, text="Comparar com a variável extraída", style="Grupo.TLabel").grid(
            row=0, column=1, sticky="w", pady=(0, 4)
        )

        for i, col in enumerate(self.observed_columns, start=1):
            ttk.Label(self.frame_mapeamento, text=col).grid(row=i, column=0, sticky="w", padx=(0, 12), pady=2)

            var = tk.StringVar()
            cfg_sugerido_id = sugestoes.get(col)
            var.set(by_id[cfg_sugerido_id]["display_name"] if cfg_sugerido_id in by_id else NAO_COMPARAR)

            combo = ttk.Combobox(
                self.frame_mapeamento, textvariable=var, values=opcoes, state="readonly", width=48
            )
            combo.grid(row=i, column=1, sticky="w", pady=2)
            self.mapeamento_vars[col] = var

    def mostrar_sobre(self):
        janela = tk.Toplevel(self)
        janela.title("Sobre")
        janela.geometry("700x600")
        janela.configure(background=COR_FUNDO)

        texto = scrolledtext.ScrolledText(janela, wrap=tk.WORD)
        texto.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        texto.insert("1.0", about_text.ABOUT_TEXT)
        texto.config(state="disabled")

        ttk.Button(janela, text="Fechar", command=janela.destroy).pack(pady=(0, 8))

    # ------------------------------------------------------ extração GEE

    def on_extrair_variaveis(self):
        if not self.area_path:
            messagebox.showwarning("Faltando informação", "Selecione o shapefile/GeoJSON da área na aba 1.")
            return

        selecionadas = [cfg for cfg in self.collections if self.variavel_vars[cfg["id"]].get()]
        if not selecionadas:
            messagebox.showwarning("Faltando informação", "Marque ao menos uma variável para extrair.")
            return

        if not self.projeto_var.get().strip():
            messagebox.showwarning("Faltando informação", "Informe o ID do projeto do Earth Engine na aba 2.")
            return

        ano_inicial_txt = self.ano_inicial_var.get().strip()
        ano_final_txt = self.ano_final_var.get().strip()

        if not ano_inicial_txt or not ano_final_txt:
            messagebox.showwarning(
                "Faltando informação", "Informe o ano inicial e o ano final da análise na aba 2."
            )
            return

        try:
            ano_inicial = int(ano_inicial_txt)
            ano_final = int(ano_final_txt)
        except ValueError:
            messagebox.showwarning("Faltando informação", "Ano inicial e ano final devem ser números (ex.: 2000).")
            return

        if ano_inicial > ano_final:
            messagebox.showwarning("Faltando informação", "O ano inicial não pode ser maior que o ano final.")
            return

        area_path = self.area_path
        area_multiple = self.area_mode_var.get() == "multiple"
        area_auto_ids = self.area_auto_id_var.get()
        area_id_field = self.area_id_var.get().strip()
        if area_multiple and not area_auto_ids and not area_id_field:
            messagebox.showwarning(
                "Identificação das feições",
                "Selecione um campo ID ou marque a criação automática de IDs sequenciais.",
            )
            return
        projeto_id = self.projeto_var.get().strip()
        collections_full = self.collections

        def tarefa(progress_cb):
            gee_service.initialize_ee(projeto_id, progress_cb)
            feicoes = gee_service.load_area_from_file(
                area_path,
                id_field=area_id_field if area_multiple and not area_auto_ids else None,
                generate_ids=area_multiple and area_auto_ids,
                progress_cb=progress_cb,
            )
            df = gee_service.extract_variables(
                selecionadas, collections_full, feicoes,
                start_year=ano_inicial, end_year=ano_final, progress_cb=progress_cb,
            )
            return {"df": df}

        self._iniciar_execucao("Iniciando extração...")

        worker.run_in_background(
            self, tarefa,
            on_done=self.on_extracao_concluida,
            on_error=self.on_execucao_erro,
            on_progress=self.on_progresso,
        )

    def on_extracao_concluida(self, resultado):
        self._finalizar_execucao("Extração concluída.")

        self.extracted_df = resultado["df"]
        by_id = collections_config.index_by_id(self.collections)
        colunas_variaveis = [c for c in self.extracted_df.columns if c not in ("id_feicao", "data", "ano", "mes")]
        self.extracted_cfgs = [by_id[c] for c in colunas_variaveis if c in by_id]

        n_meses = self.extracted_df["data"].nunique()
        n_feicoes = self.extracted_df["id_feicao"].nunique()
        periodo = ""
        if n_meses:
            periodo = f", de {self.extracted_df['data'].min()} a {self.extracted_df['data'].max()}"

        avisos_cobertura = []
        n_registros_esperados = n_meses * n_feicoes
        for cfg in self.extracted_cfgs:
            col = cfg["id"]
            validos = self.extracted_df[col].notna()
            n_validos = int(validos.sum())
            if n_validos == 0:
                avisos_cobertura.append(f"  - {cfg['display_name']}: nenhum dado no período pedido")
            elif n_validos < n_registros_esperados:
                datas_validas = self.extracted_df.loc[validos, "data"]
                avisos_cobertura.append(
                    f"  - {cfg['display_name']}: só {n_validos} de {n_registros_esperados} "
                    "registros (feição × mês) têm dado "
                    f"(cobertura real de {datas_validas.min()} a {datas_validas.max()} — a "
                    "coleção de origem não cobre o resto do período pedido)"
                )

        texto = (
            f"{len(self.extracted_cfgs)} variável(is) extraída(s), {n_meses} mês(es){periodo}, "
            f"para {n_feicoes} feição(ões)."
        )
        if avisos_cobertura:
            texto += "\nAtenção, cobertura incompleta em:\n" + "\n".join(avisos_cobertura)

        self.label_extracao_status.config(text=texto)

        self.botao_baixar_extraido.config(state="normal")
        self._atualizar_mapeamento()

    def baixar_extraido(self):
        if self.extracted_df is None:
            return

        caminho = filedialog.asksaveasfilename(
            title="Baixar dados extraídos",
            defaultextension=".xlsx",
            filetypes=[("Planilha Excel", "*.xlsx")],
        )
        if not caminho:
            return

        try:
            export_utils.export_extracted_to_xlsx(self.extracted_df, self.extracted_cfgs, caminho)
        except Exception as exc:
            messagebox.showerror("Baixar dados extraídos", f"Falha ao exportar: {exc}")
            return

        messagebox.showinfo("Baixar dados extraídos", f"Dados exportados para:\n{caminho}")

    # ------------------------------------------------------------ validação

    def on_executar(self):
        if self.extracted_df is None:
            messagebox.showwarning(
                "Faltando informação",
                "Extraia as variáveis do Earth Engine na aba 2 antes de validar.",
            )
            return

        if self.extracted_df["id_feicao"].nunique() > 1:
            messagebox.showwarning(
                "Validação para múltiplas feições",
                "A extração foi feita para mais de uma feição. Os dados podem ser baixados "
                "na aba 2, identificados pela coluna 'id_feicao'. A validação atual usa uma "
                "única série observada e, por isso, deve ser executada para uma feição por vez.",
            )
            return

        if self.observed_df is None:
            messagebox.showwarning("Faltando informação", "Selecione a planilha de dados observados na aba 3.")
            return

        nomes_para_cfg = {cfg["display_name"]: cfg for cfg in self.extracted_cfgs}
        pares = []
        for obs_col, var in self.mapeamento_vars.items():
            escolha = var.get()
            if escolha and escolha != NAO_COMPARAR and escolha in nomes_para_cfg:
                pares.append((obs_col, nomes_para_cfg[escolha]))

        if not pares:
            messagebox.showwarning(
                "Faltando informação",
                "Associe pelo menos uma coluna observada a uma variável extraída na aba 3.",
            )
            return

        extracted_df = self.extracted_df
        observed_df = self.observed_df

        def tarefa(progress_cb):
            resultados = []
            for obs_col, cfg in pares:
                progress_cb(f"Validando '{cfg['display_name']}'...")

                dados = observed_data.merge_datasets(
                    extracted_df, observed_df,
                    extraido_col=cfg["id"], observado_col=obs_col,
                    agg=cfg.get("agg", "mean"),
                )

                metricas_calc = metrics.calcular_metricas(dados["valor_observado"], dados[cfg["id"]])
                label = f"{cfg['display_name']} ({cfg.get('unit', '-')})"
                figuras = {
                    chave: builder(dados, cfg["id"], label=label)
                    for chave, _titulo, builder in FIGURAS_INFO
                }

                resultados.append({
                    "id": cfg["id"],
                    "label": cfg["display_name"],
                    "dados": dados,
                    "metricas": metricas_calc,
                    "figuras": figuras,
                })

            return {"resultados": resultados}

        self._iniciar_execucao("Iniciando validação...")

        worker.run_in_background(
            self, tarefa,
            on_done=self.on_execucao_concluida,
            on_error=self.on_execucao_erro,
            on_progress=self.on_progresso,
        )

    def _iniciar_execucao(self, mensagem):
        self.botao_executar.config(state="disabled")
        self.botao_extrair.config(state="disabled")
        self.progressbar.start(12)
        self.status_var.set(mensagem)

    def _finalizar_execucao(self, mensagem):
        self.progressbar.stop()
        self.botao_executar.config(state="normal")
        self.botao_extrair.config(state="normal")
        self.status_var.set(mensagem)

    def on_progresso(self, mensagem):
        self.status_var.set(mensagem)

    def on_execucao_concluida(self, resultado):
        self.resultados = resultado["resultados"]
        self._popular_lista_resultados()

        validadas_ids = {r["id"] for r in self.resultados}
        nao_validadas = [
            cfg["display_name"] for cfg in self.extracted_cfgs if cfg["id"] not in validadas_ids
        ]

        mensagem = "Validação concluída."
        if nao_validadas:
            mensagem += (
                f" {len(nao_validadas)} variável(is) extraída(s) não têm coluna "
                f"observada associada e não aparecem aqui: {', '.join(nao_validadas)}. "
                "Use 'Baixar dados extraídos' na aba 2 para pegar essas também."
            )
        self._finalizar_execucao(mensagem)

        if self.resultados:
            self._selecionar_resultado(0)
            self.botao_exportar_tudo.config(state="normal")

        self.notebook.select(self.aba_resultados)

    def on_execucao_erro(self, excecao):
        self._finalizar_execucao("Erro na execução.")
        messagebox.showerror("Erro", str(excecao))

    def _popular_lista_resultados(self):
        self.lista_resultados.delete(0, tk.END)
        for r in self.resultados:
            self.lista_resultados.insert(tk.END, r["label"])

    def _on_selecionar_resultado(self, _event=None):
        selecao = self.lista_resultados.curselection()
        if not selecao:
            return
        self._selecionar_resultado(selecao[0])

    def _selecionar_resultado(self, idx):
        self.resultado_atual = self.resultados[idx]
        self.dados = self.resultado_atual["dados"]
        self.metricas = self.resultado_atual["metricas"]
        self.figuras = self.resultado_atual["figuras"]

        self.lista_resultados.selection_clear(0, tk.END)
        self.lista_resultados.selection_set(idx)
        self.lista_resultados.activate(idx)

        self._popular_metricas()
        self._popular_figuras()

        self.botao_exportar_dados.config(state="normal")
        for botao in self.botoes_exportar_png.values():
            botao.config(state="normal")

    def _popular_metricas(self):
        for widget in self.frame_metricas.winfo_children():
            widget.destroy()

        for i, (nome, valor) in enumerate(self.metricas.items()):
            ttk.Label(self.frame_metricas, text=f"{nome}:", style="Grupo.TLabel").grid(
                row=0, column=2 * i, sticky="e", padx=(0 if i == 0 else 12, 4)
            )
            ttk.Label(self.frame_metricas, text=f"{valor:.3f}").grid(
                row=0, column=2 * i + 1, sticky="w"
            )

    def _popular_figuras(self):
        for chave, _titulo, _builder in FIGURAS_INFO:
            frame_canvas = self.frames_figuras[chave]

            for widget in frame_canvas.winfo_children():
                widget.destroy()

            canvas = FigureCanvasTkAgg(self.figuras[chave], master=frame_canvas)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            self.canvas_por_figura[chave] = canvas

    # --------------------------------------------------------- exportação

    def exportar_dados(self):
        if self.dados is None:
            return

        caminho = filedialog.asksaveasfilename(
            title="Exportar dados",
            defaultextension=".xlsx",
            filetypes=[("Planilha Excel", "*.xlsx")],
        )
        if not caminho:
            return

        try:
            export_utils.export_dataframe_to_xlsx(self.dados, self.metricas, caminho)
        except Exception as exc:
            messagebox.showerror("Exportar dados", f"Falha ao exportar: {exc}")
            return

        messagebox.showinfo("Exportar dados", f"Dados exportados para:\n{caminho}")

    def exportar_tudo(self):
        if not self.resultados:
            return

        caminho = filedialog.asksaveasfilename(
            title="Exportar todas as variáveis",
            defaultextension=".xlsx",
            filetypes=[("Planilha Excel", "*.xlsx")],
        )
        if not caminho:
            return

        try:
            export_utils.export_all_results_to_xlsx(self.resultados, caminho)
        except Exception as exc:
            messagebox.showerror("Exportar todas as variáveis", f"Falha ao exportar: {exc}")
            return

        messagebox.showinfo("Exportar todas as variáveis", f"Dados exportados para:\n{caminho}")

    def exportar_grafico(self, chave):
        if chave not in self.figuras:
            return

        caminho = filedialog.asksaveasfilename(
            title="Exportar gráfico",
            defaultextension=".png",
            filetypes=[("Imagem PNG", "*.png")],
        )
        if not caminho:
            return

        try:
            export_utils.export_figure_to_png(self.figuras[chave], caminho)
        except Exception as exc:
            messagebox.showerror("Exportar gráfico", f"Falha ao exportar: {exc}")
            return

        messagebox.showinfo("Exportar gráfico", f"Gráfico exportado para:\n{caminho}")


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
