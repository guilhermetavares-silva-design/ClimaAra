"""Carrega e valida o arquivo de configuração das coleções do Google Earth Engine.

Cada coleção descrita em `collections_config.json` vira uma variável selecionável
na interface. Para adicionar uma nova variável (temperatura, umidade, ETP, vento...)
basta editar esse JSON — nenhum código Python precisa mudar.

Duas categorias de entrada são aceitas:

- Diretas: extraídas de um `asset_id`/`band` do Earth Engine. `band` pode ser
  omitido (null) para que o programa detecte automaticamente a única banda
  da coleção. `agg` diz como agregar valores diários em totais mensais
  ("sum" para variáveis acumulativas como chuva/ETP, "mean" para variáveis
  de estado como temperatura/umidade/vento/pressão).
- Derivadas: calculadas em Python a partir de duas outras variáveis diretas
  já agregadas mensalmente (hoje, usado para velocidade/direção do vento a
  partir das componentes U/V). Têm `derived_from` (lista com 2 ids) e
  `compute` em vez de `asset_id`/`band`/`agg`.
"""

import json
from pathlib import Path

DIRECT_REQUIRED_FIELDS = ["id", "display_name", "group", "asset_id", "scale_m", "agg"]
DERIVED_REQUIRED_FIELDS = ["id", "display_name", "group", "derived_from", "compute"]

DEFAULT_CONFIG_PATH = Path(__file__).parent / "collections_config.json"


class CollectionConfigError(Exception):
    pass


def load_collections(path=DEFAULT_CONFIG_PATH):
    """Lê o JSON de coleções e retorna a lista de dicts já validada."""
    path = Path(path)

    if not path.exists():
        raise CollectionConfigError(
            f"Arquivo de configuração de coleções não encontrado: {path}"
        )

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise CollectionConfigError(
            f"O arquivo {path.name} não é um JSON válido: {exc}"
        ) from exc

    collections = raw.get("collections", [])

    if not collections:
        raise CollectionConfigError(
            f"O arquivo {path.name} não contém nenhuma coleção em 'collections'."
        )

    for entry in collections:
        _validate_entry(entry, path.name)

    ids = [entry["id"] for entry in collections]
    duplicados = {i for i in ids if ids.count(i) > 1}
    if duplicados:
        raise CollectionConfigError(
            f"IDs de coleção duplicados em {path.name}: {', '.join(sorted(duplicados))}"
        )

    ids_validos = set(ids)
    for entry in collections:
        if is_derived(entry):
            for dep in entry["derived_from"]:
                if dep not in ids_validos:
                    raise CollectionConfigError(
                        f"A coleção derivada '{entry['display_name']}' referencia "
                        f"o id '{dep}', que não existe em {path.name}."
                    )

    return collections


def is_derived(entry):
    return "derived_from" in entry


def _validate_entry(entry, filename):
    nome = entry.get("display_name", entry.get("id", "<sem id>"))

    if is_derived(entry):
        faltando = [c for c in DERIVED_REQUIRED_FIELDS if c not in entry]
        if faltando:
            raise CollectionConfigError(
                f"A coleção derivada '{nome}' em {filename} está sem os campos "
                f"obrigatórios: {', '.join(faltando)}"
            )
        if not isinstance(entry["derived_from"], list) or len(entry["derived_from"]) != 2:
            raise CollectionConfigError(
                f"A coleção derivada '{nome}' precisa de 'derived_from' com "
                "exatamente 2 ids (ex.: componentes U e V do vento)."
            )
        if entry["compute"] not in ("wind_speed", "wind_direction"):
            raise CollectionConfigError(
                f"A coleção derivada '{nome}' tem 'compute' desconhecido: "
                f"{entry['compute']!r}. Valores aceitos: wind_speed, wind_direction."
            )
        return

    faltando = [campo for campo in DIRECT_REQUIRED_FIELDS if campo not in entry]
    if faltando:
        raise CollectionConfigError(
            f"A coleção '{nome}' em {filename} está sem os campos obrigatórios: "
            f"{', '.join(faltando)}"
        )

    if entry["agg"] not in ("sum", "mean"):
        raise CollectionConfigError(
            f"A coleção '{nome}' tem 'agg' inválido: {entry['agg']!r}. "
            "Use 'sum' (variáveis acumulativas) ou 'mean' (variáveis de estado)."
        )

    transform = entry.get("transform")
    if transform is not None and not isinstance(transform, dict):
        raise CollectionConfigError(
            f"A coleção '{nome}' tem 'transform' inválido "
            "(esperado um objeto com 'multiply'/'add' ou nulo)."
        )


def index_by_id(collections):
    return {entry["id"]: entry for entry in collections}


def get_collection_by_id(collections, collection_id):
    for entry in collections:
        if entry["id"] == collection_id:
            return entry
    raise CollectionConfigError(f"Coleção não encontrada: {collection_id}")


def get_collection_by_display_name(collections, display_name):
    for entry in collections:
        if entry["display_name"] == display_name:
            return entry
    raise CollectionConfigError(f"Coleção não encontrada: {display_name}")


def group_collections(collections):
    """Agrupa as coleções por 'group', preservando a ordem de aparição."""
    grupos = {}
    for entry in collections:
        grupos.setdefault(entry["group"], []).append(entry)
    return grupos
