"""Exportação dos resultados: dados extraídos/combinados em XLSX e gráficos
em PNG."""

import re
from pathlib import Path

import pandas as pd


def _nome_aba_valido(nome, usados):
    """Excel só aceita nomes de aba com até 31 caracteres e sem
    alguns símbolos; garante também que não haja abas repetidas."""
    limpo = re.sub(r"[\[\]:*?/\\]", "_", str(nome)).strip() or "dados"
    limpo = limpo[:31]

    base = limpo
    sufixo = 1
    while limpo in usados:
        sufixo_str = f"_{sufixo}"
        limpo = base[: 31 - len(sufixo_str)] + sufixo_str
        sufixo += 1

    usados.add(limpo)
    return limpo


def export_dataframe_to_xlsx(dados, metricas, path):
    """Salva os dados combinados (observado x extraído) e a tabela de
    métricas de UM par variável observada/extraída em um único XLSX, cada
    um em sua própria aba."""
    path = Path(path)

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        dados.to_excel(writer, sheet_name="dados", index=False)

        metricas_df = pd.DataFrame(
            {"métrica": list(metricas.keys()), "valor": list(metricas.values())}
        )
        metricas_df.to_excel(writer, sheet_name="metricas", index=False)

    return path


def export_extracted_to_xlsx(df_extraido, cfgs, path):
    """Salva a extração bruta do Earth Engine (uma ou mais variáveis, sem
    depender de dados observados) em um único XLSX, com uma aba de dados e
    uma aba descrevendo cada variável (unidade, coleção, agregação). Em
    extrações com múltiplas áreas, a coluna ``id_feicao`` identifica a
    feição de cada registro."""
    path = Path(path)

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df_extraido.to_excel(writer, sheet_name="dados_extraidos", index=False)

        descricao = pd.DataFrame([
            {
                "coluna": cfg["id"],
                "variavel": cfg["display_name"],
                "unidade": cfg.get("unit", "-"),
                "grupo": cfg.get("group", "-"),
                "resolucao_temporal_origem": cfg.get("temporal_resolution", "-"),
            }
            for cfg in cfgs
        ])
        descricao.to_excel(writer, sheet_name="variaveis", index=False)

    return path


def export_all_results_to_xlsx(pares, path):
    """Salva TODOS os pares validados (observado x extraído) num único
    XLSX: uma aba de dados por variável e uma aba única "metricas" com uma
    linha por variável.

    `pares`: lista de dicts com chaves "label", "dados" (DataFrame) e
    "metricas" (dict).
    """
    path = Path(path)
    usados = set()

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        linhas_metricas = []

        for par in pares:
            aba = _nome_aba_valido(par["label"], usados)
            par["dados"].to_excel(writer, sheet_name=aba, index=False)

            linha = {"variavel": par["label"]}
            linha.update(par["metricas"])
            linhas_metricas.append(linha)

        pd.DataFrame(linhas_metricas).to_excel(writer, sheet_name="metricas", index=False)

    return path


def export_figure_to_png(figure, path, dpi=200):
    path = Path(path)
    figure.savefig(path, dpi=dpi, bbox_inches="tight")
    return path
