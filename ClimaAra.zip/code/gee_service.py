"""Integração com o Google Earth Engine: autenticação, área de interesse a
partir de um arquivo local (shapefile ou GeoJSON) e extração de uma ou mais
variáveis (coleções), conforme descritas em `collections_config.json`.

A extração sempre entrega uma série MENSAL, mesmo quando a coleção de
origem é diária (BR-DWGD sat-io, CHIRPS, ERA5): os valores diários são
agregados por mês em pandas, usando soma para variáveis acumulativas
(precipitação, evapotranspiração) ou média para variáveis de estado
(temperatura, umidade, vento, pressão), conforme o campo `agg` de cada
variável em collections_config.json. Isso evita comparar diretamente uma
coleção diária com uma planilha observada mensal (ou vice-versa).
"""

import contextlib
import io
from pathlib import Path

import ee
import geemap
import numpy as np
import pandas as pd

import collections_config


class GeeServiceError(Exception):
    pass


def initialize_ee(project_id, progress_cb=None):
    """Inicializa o Earth Engine, autenticando via navegador só se necessário."""
    if not project_id:
        raise GeeServiceError("Informe o ID do projeto do Google Earth Engine.")

    try:
        ee.Initialize(project=project_id)
        return
    except Exception:
        pass

    if progress_cb:
        progress_cb("Abrindo o navegador para autenticação no Google Earth Engine...")

    try:
        ee.Authenticate()
        ee.Initialize(project=project_id)
    except Exception as exc:
        raise GeeServiceError(
            "Não foi possível autenticar/inicializar o Earth Engine. "
            f"Detalhe: {exc}"
        ) from exc


def load_area_from_file(path, progress_cb=None):
    """Carrega a área de interesse a partir de um .shp ou .geojson local."""
    caminho = Path(path)

    if not caminho.exists():
        raise GeeServiceError(f"Arquivo não encontrado: {caminho}")

    ext = caminho.suffix.lower()

    if progress_cb:
        progress_cb("Lendo o arquivo de área (shapefile/GeoJSON)...")

    saida_capturada = io.StringIO()

    try:
        if ext == ".shp":
            # geemap.shp_to_ee engole exceções internamente e só faz print();
            # capturamos essa saída para conseguir repassar o motivo real do erro.
            with contextlib.redirect_stdout(saida_capturada):
                fc = geemap.shp_to_ee(str(caminho))
        elif ext in (".geojson", ".json"):
            fc = geemap.geojson_to_ee(str(caminho))
        else:
            raise GeeServiceError(
                f"Formato de arquivo não suportado: {ext}. Use .shp ou .geojson."
            )
    except GeeServiceError:
        raise
    except Exception as exc:
        raise GeeServiceError(
            "Não foi possível ler o arquivo de área. Confirme que o .shp tem os "
            f"arquivos .dbf/.shx/.prj na mesma pasta. Detalhe: {exc}"
        ) from exc

    if fc is None:
        detalhe = saida_capturada.getvalue().strip()
        raise GeeServiceError(
            "Não foi possível converter o arquivo de área para o Earth Engine. "
            "Confira se o .shp tem os arquivos .dbf/.shx/.prj na mesma pasta e se "
            "as bibliotecas 'geopandas' e 'pycrs' estão instaladas (necessárias "
            "para reprojetar shapefiles que não estão em WGS84)."
            + (f"\nDetalhe técnico: {detalhe}" if detalhe else "")
        )

    try:
        return fc.geometry().dissolve(maxError=1)
    except Exception as exc:
        raise GeeServiceError(
            f"Não foi possível calcular a geometria da área selecionada. Detalhe: {exc}"
        ) from exc


def _detectar_banda(colecao, cfg):
    """Detecta automaticamente o nome da (única) banda de uma coleção,
    usado quando `band` não está definido em collections_config.json."""
    try:
        bandas = colecao.first().bandNames().getInfo()
    except Exception as exc:
        raise GeeServiceError(
            f"Não foi possível detectar a banda de '{cfg['display_name']}' "
            f"({cfg['asset_id']}). Detalhe: {exc}"
        ) from exc

    if not bandas:
        raise GeeServiceError(
            f"A coleção '{cfg['asset_id']}' (variável '{cfg['display_name']}') "
            "não tem nenhuma banda."
        )

    return bandas[0]


def _aplicar_transform(imagem, banda, transform, output_id):
    imagem_banda = imagem.select(banda)

    if transform:
        if "multiply" in transform:
            imagem_banda = imagem_banda.multiply(transform["multiply"])
        if "add" in transform:
            imagem_banda = imagem_banda.add(transform["add"])

    return (
        imagem_banda
        .rename(output_id)
        .copyProperties(imagem, ["system:time_start", "system:time_end"])
    )


def _extrair_feature(imagem, geometria, scale_m, reducer_name):
    reducer = getattr(ee.Reducer, reducer_name)()

    stats = imagem.reduceRegion(
        reducer=reducer,
        geometry=geometria,
        scale=scale_m,
        maxPixels=1e10,
    )

    data = imagem.date()

    return ee.Feature(None, stats).set({
        "ano": data.get("year"),
        "mes": data.get("month"),
    })


def _feature_collection_to_df(fc):
    """Equivalente a geemap.ee_to_df, mas sem o bug de
    `df.drop(columns=["geo"], axis=1)` (inválido em pandas >= 2), que faz
    geemap.ee_to_df falhar com versões recentes do pandas."""
    sem_geometria = fc.map(
        lambda f: ee.Feature(None, f.toDictionary(f.propertyNames().sort()))
    )
    df = ee.data.computeFeatures({
        "expression": sem_geometria,
        "fileFormat": "PANDAS_DATAFRAME",
    })
    if "geo" in df.columns:
        df = df.drop(columns=["geo"])
    return df


def extract_variable(cfg, geometria, start_year=None, end_year=None, progress_cb=None):
    """Extrai uma única variável direta (não derivada) e devolve um
    DataFrame mensal com colunas: data (AAAA-MM), ano, mes, <id da variável>.

    Se a coleção de origem for diária, os valores são agregados por mês
    (soma ou média, conforme `cfg['agg']`) antes de retornar.

    Se `start_year`/`end_year` forem informados, a coleção é filtrada para
    o período de 1º de janeiro de `start_year` até 31 de dezembro de
    `end_year` antes da extração.
    """
    var_id = cfg["id"]
    scale_m = cfg["scale_m"]
    reducer_name = cfg.get("reducer", "mean")
    transform = cfg.get("transform")
    agg = cfg["agg"]

    if progress_cb:
        progress_cb(f"Extraindo '{cfg['display_name']}' do Earth Engine...")

    try:
        colecao = ee.ImageCollection(cfg["asset_id"])

        if start_year is not None and end_year is not None:
            colecao = colecao.filterDate(f"{start_year}-01-01", f"{end_year + 1}-01-01")

        banda = cfg.get("band")
        if not banda:
            banda = _detectar_banda(colecao, cfg)

        fc = ee.FeatureCollection(
            colecao
            .map(lambda img: _aplicar_transform(img, banda, transform, var_id))
            .map(lambda img: _extrair_feature(img, geometria, scale_m, reducer_name))
        )

        df = _feature_collection_to_df(fc)
    except GeeServiceError:
        raise
    except Exception as exc:
        raise GeeServiceError(
            f"Falha ao extrair '{cfg['display_name']}' do Earth Engine. Detalhe: {exc}"
        ) from exc

    if df is None or df.empty:
        raise GeeServiceError(
            f"A extração de '{cfg['display_name']}' não retornou nenhum dado. "
            "Verifique a área selecionada, o período (ano inicial/final) e o ID "
            "do asset da coleção."
        )

    if var_id not in df.columns:
        raise GeeServiceError(
            f"A extração de '{cfg['display_name']}' não retornou a banda esperada "
            f"('{banda}'). Confira o asset_id/band em collections_config.json."
        )

    df["ano"] = df["ano"].astype(int)
    df["mes"] = df["mes"].astype(int)

    df_mensal = df.groupby(["ano", "mes"], as_index=False)[var_id].agg(agg)
    df_mensal["data"] = df_mensal.apply(
        lambda r: f"{int(r['ano'])}-{int(r['mes']):02d}", axis=1
    )

    return df_mensal[["data", "ano", "mes", var_id]].sort_values("data").reset_index(drop=True)


def _wind_speed(u, v):
    return np.sqrt(u ** 2 + v ** 2)


def _wind_direction(u, v):
    """Direção meteorológica de onde o vento vem (graus, 0-360, 0=N),
    calculada a partir das componentes U (leste+) e V (norte+) já
    agregadas mensalmente (média vetorial — a forma correta de obter a
    direção média do vento, evitando o erro de médias circulares)."""
    return (270 - np.degrees(np.arctan2(v, u))) % 360


def extract_variables(selected_cfgs, all_collections, geometria, start_year=None, end_year=None, progress_cb=None):
    """Extrai uma ou mais variáveis para a área dada e monta um único
    DataFrame largo mensal, com uma coluna por variável (nomeada pelo seu
    `id`). Variáveis derivadas (ex.: velocidade/direção do vento) puxam
    automaticamente suas dependências diretas, mesmo que não tenham sido
    marcadas explicitamente pelo usuário.

    `start_year`/`end_year` (inclusive), se informados, limitam a extração
    a esse período.
    """
    if not selected_cfgs:
        raise GeeServiceError("Nenhuma variável selecionada para extração.")

    if (start_year is None) != (end_year is None):
        raise GeeServiceError("Informe o ano inicial e o ano final, ou deixe ambos em branco.")

    if start_year is not None and end_year is not None and start_year > end_year:
        raise GeeServiceError("O ano inicial não pode ser maior que o ano final.")

    by_id = collections_config.index_by_id(all_collections)

    ids_diretos = []
    derivadas = []
    for cfg in selected_cfgs:
        if collections_config.is_derived(cfg):
            derivadas.append(cfg)
            ids_diretos.extend(cfg["derived_from"])
        else:
            ids_diretos.append(cfg["id"])

    vistos = set()
    ids_diretos_unicos = [i for i in ids_diretos if not (i in vistos or vistos.add(i))]

    df_final = None
    for var_id in ids_diretos_unicos:
        cfg = by_id.get(var_id)
        if cfg is None:
            raise GeeServiceError(
                f"Variável desconhecida referenciada na configuração: {var_id}"
            )
        df_var = extract_variable(cfg, geometria, start_year, end_year, progress_cb)
        df_final = df_var if df_final is None else df_final.merge(
            df_var, on=["data", "ano", "mes"], how="outer"
        )

    for cfg in derivadas:
        if progress_cb:
            progress_cb(f"Calculando '{cfg['display_name']}'...")

        id_u, id_v = cfg["derived_from"]
        if id_u not in df_final.columns or id_v not in df_final.columns:
            raise GeeServiceError(
                f"Não foi possível calcular '{cfg['display_name']}': faltam as "
                f"colunas base ({id_u}, {id_v})."
            )

        u = df_final[id_u]
        v = df_final[id_v]

        if cfg["compute"] == "wind_speed":
            df_final[cfg["id"]] = _wind_speed(u, v)
        elif cfg["compute"] == "wind_direction":
            df_final[cfg["id"]] = _wind_direction(u, v)
        else:
            raise GeeServiceError(f"'compute' desconhecido: {cfg['compute']!r}")

    return df_final.sort_values("data").reset_index(drop=True)
