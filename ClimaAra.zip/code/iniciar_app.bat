@echo off
cd /d "%~dp0"

set PYTHON_CMD=

where py >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=py -3
    goto instalar
)

where python >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=python
    goto instalar
)

echo Python nao foi encontrado neste computador.
echo Instale o Python 3.12 (marcando a opcao "Add python.exe to PATH"
echo durante a instalacao) em: https://www.python.org/downloads/
echo Depois, rode este arquivo de novo.
echo.
pause
exit /b 1

:instalar
echo Verificando dependencias (so demora na primeira vez)...
%PYTHON_CMD% -m pip install -q -r requirements.txt

echo Iniciando o AraClima...
%PYTHON_CMD% app.py

if errorlevel 1 (
    echo.
    echo O programa fechou com um erro. Copie a mensagem acima e mande para guilherme.tavares-silva@unesp.br
    pause
)
