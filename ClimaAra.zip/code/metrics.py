"""Métricas de acurácia entre a série observada e a série simulada/extraída."""

import numpy as np
from sklearn.metrics import r2_score


def calcular_metricas(obs, sim):
    obs = np.array(obs, dtype=float)
    sim = np.array(sim, dtype=float)

    r2 = r2_score(obs, sim)

    rmse = np.sqrt(np.mean((sim - obs) ** 2))

    nse = 1 - (
        np.sum((sim - obs) ** 2)
        / np.sum((obs - np.mean(obs)) ** 2)
    )

    pbias = 100 * np.sum(sim - obs) / np.sum(obs)

    r = np.corrcoef(obs, sim)[0, 1]
    alpha = np.std(sim) / np.std(obs)
    beta = np.mean(sim) / np.mean(obs)

    kge = 1 - np.sqrt(
        (r - 1) ** 2
        + (alpha - 1) ** 2
        + (beta - 1) ** 2
    )

    return {
        "R²": r2,
        "RMSE": rmse,
        "NSE": nse,
        "KGE": kge,
        "PBIAS (%)": pbias,
    }
