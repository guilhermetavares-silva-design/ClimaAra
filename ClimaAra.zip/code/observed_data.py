"""Leitura da planilha XLSX com os dados observados (estação de referência).

Dois formatos são aceitos, detectados automaticamente:

1. "Aba por ano" — uma aba para cada ano (nome da aba = ano, ex.: "2020"),
   com uma coluna "DIA" e uma linha "Total" contendo os totais mensais nas
   colunas JAN..DEZ. É o formato usado nas planilhas de estação do CEAPLA.
   Sempre interpretado como uma única variável de precipitação mensal.

2. "Data + variáveis" — uma única aba com uma coluna de data (data completa,
   "AAAA-MM" ou "AAAA-MM-DD") e UMA OU MAIS colunas de valores observados,
   uma por variável (ex.: Precipitacao, TMedia, TMax, Umidade...). O nome de
   cada coluna é o que aparece no cabeçalho da planilha. As datas podem ser
   diárias ou mensais — isso é detectado automaticamente e usado depois, no
   momento de comparar com uma variável do Earth Engine, para agregar
   corretamente (soma ou média) os valores diários em totais/médias mensais.

Em ambos os casos o resultado inclui as colunas `ano`, `mes`, `data`
("AAAA-MM") e uma coluna por variável observada.
"""

import re
import unicodedata

import pandas as pd

MESES = ["JAN", "FEV", "MAR", "ABR", "MAI", "JUN",
          "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"]

DATE_COLUMN_HINTS = ["data", "date", "dia", "periodo", "período"]

# Sinônimos usados para sugerir automaticamente a que variável extraída do
# GEE cada coluna observada provavelmente corresponde. É só uma sugestão
# inicial pré-selecionada na interface — o usuário sempre pode trocar.
SYNONYMS = {
    "precipitacao": ["chuva", "precip", "pr", "prcp", "rain"],
    "et": ["evapotranspiracao", "evapotranspiração", "eto", "etp", "etr", "et0"],
    "rh": ["umidade", "humidity", "rh", "ur"],
    "rs": ["radiacao", "radiação", "radiation", "rs", "srad"],
    "tmax": ["tmax", "tmaxima", "tmáxima", "temperaturamaxima", "maxima", "máxima"],
    "tmin": ["tmin", "tminima", "tmínima", "temperaturaminima", "minima", "mínima"],
    "tmed": ["tmed", "tmedia", "tmédia", "temperaturamedia", "temp", "temperatura"],
    "tdew": ["orvalho", "dewpoint", "tdew", "pontodeorvalho"],
    "vento_vel": ["vento", "wind", "velocidadedovento", "velvento", "u2"],
    "vento_dir": ["direcao", "direção", "direcaodovento", "winddir", "dirvento"],
    "pressao": ["pressao", "pressão", "pressure", "mslp"],
}


class ObservedDataError(Exception):
    pass


def _strip_accents(texto):
    nfkd = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def _normaliza(texto):
    txt = _strip_accents(str(texto)).strip().lower()
    return re.sub(r"[^a-z0-9]", "", txt)


def load_observed(path):
    """Retorna (DataFrame, nome_do_formato_detectado, lista_de_colunas_de_variavel, is_daily)."""
    xls = pd.ExcelFile(path)

    anos_encontrados = [
        aba for aba in xls.sheet_names
        if re.fullmatch(r"\d{4}", aba.strip())
    ]

    if anos_encontrados:
        df = _parse_year_sheets(xls, anos_encontrados)
        return df, "aba-por-ano (com linha Total)", ["Precipitacao"], False

    df, colunas_valor, is_daily = _parse_wide(xls)
    return df, "planilha com data e uma ou mais variáveis", colunas_valor, is_daily


def _parse_year_sheets(xls, anos_encontrados):
    resultado = []

    for nome_aba in anos_encontrados:
        try:
            ano = int(nome_aba.strip())
        except ValueError:
            continue

        tabela = xls.parse(nome_aba, header=2)
        tabela.columns = tabela.columns.astype(str).str.strip().str.upper()

        if "DIA" not in tabela.columns:
            continue

        linha_total = tabela[
            tabela["DIA"].astype(str).str.strip().str.upper() == "TOTAL"
        ]

        if linha_total.empty:
            continue

        linha_total = linha_total.iloc[0]

        for i, mes in enumerate(MESES, start=1):
            if mes not in tabela.columns:
                continue
            resultado.append({
                "ano": ano,
                "mes": i,
                "data": f"{ano}-{i:02d}",
                "data_dia": f"{ano}-{i:02d}-01",
                "Precipitacao": float(linha_total[mes]),
            })

    if not resultado:
        raise ObservedDataError(
            "Nenhuma aba de ano válida foi encontrada (esperado: aba nomeada "
            "com o ano, coluna 'DIA' e uma linha 'Total' com os meses JAN..DEZ)."
        )

    return pd.DataFrame(resultado).sort_values("data").reset_index(drop=True)


def _parse_wide(xls):
    primeira_aba = xls.sheet_names[0]
    tabela = xls.parse(primeira_aba)

    if tabela.shape[1] < 2:
        raise ObservedDataError(
            "A planilha precisa ter ao menos duas colunas: uma de data e uma "
            "ou mais de valores observados."
        )

    colunas_normalizadas = {col: _normaliza(col) for col in tabela.columns}
    col_data = _encontra_coluna_data(tabela, colunas_normalizadas)

    datas = pd.to_datetime(tabela[col_data], errors="coerce", dayfirst=True)

    if datas.isna().all():
        # tenta formato "AAAA-MM"
        datas = pd.to_datetime(
            tabela[col_data].astype(str).str.strip() + "-01", errors="coerce"
        )

    if datas.isna().all():
        raise ObservedDataError(
            f"Não foi possível interpretar a coluna de data '{col_data}'. "
            "Use datas completas, 'AAAA-MM' ou 'AAAA-MM-DD'."
        )

    colunas_valor = []
    dados = {
        "ano": datas.dt.year,
        "mes": datas.dt.month,
        "data_dia": datas.dt.strftime("%Y-%m-%d"),
    }

    for col in tabela.columns:
        if col == col_data:
            continue
        valores = pd.to_numeric(tabela[col], errors="coerce")
        if valores.notna().sum() == 0:
            continue
        nome_coluna = str(col).strip()
        dados[nome_coluna] = valores
        colunas_valor.append(nome_coluna)

    if not colunas_valor:
        raise ObservedDataError(
            "Não foi encontrada nenhuma coluna numérica de valores observados "
            "além da coluna de data."
        )

    df = pd.DataFrame(dados)
    df = df.dropna(subset=["ano", "mes"])
    df["ano"] = df["ano"].astype(int)
    df["mes"] = df["mes"].astype(int)
    df["data"] = df.apply(lambda r: f"{r['ano']}-{r['mes']:02d}", axis=1)

    if df.empty:
        raise ObservedDataError("Nenhuma linha com data válida foi encontrada na planilha.")

    is_daily = datas.dt.day.nunique(dropna=True) > 1

    colunas_finais = ["data", "ano", "mes", "data_dia"] + colunas_valor
    df = df[colunas_finais].sort_values("data_dia").reset_index(drop=True)

    return df, colunas_valor, is_daily


def _encontra_coluna_data(tabela, colunas_normalizadas):
    for col, normalizado in colunas_normalizadas.items():
        if any(dica.replace(" ", "") in normalizado for dica in DATE_COLUMN_HINTS):
            return col
    # sem cabeçalho reconhecível: assume a primeira coluna
    return tabela.columns[0]


def suggest_variable_mapping(colunas_observadas, cfgs_extraidas):
    """Sugere, para cada coluna observada, a variável extraída (cfg) mais
    provável, comparando nomes normalizados e sinônimos conhecidos. Retorna
    {coluna_observada: cfg_id ou None}. É só uma pré-seleção — o usuário
    confirma ou troca na interface."""
    sugestoes = {}

    cfgs_norm = []
    for cfg in cfgs_extraidas:
        chave_sinonimo = None
        for chave, termos in SYNONYMS.items():
            if any(t in _normaliza(cfg["display_name"]) or t in _normaliza(cfg["id"])
                   for t in termos):
                chave_sinonimo = chave
                break
        cfgs_norm.append((cfg, _normaliza(cfg["display_name"]), _normaliza(cfg["id"]), chave_sinonimo))

    for col in colunas_observadas:
        col_norm = _normaliza(col)
        melhor = None

        # 1) casamento direto pelo id ou nome de exibição da variável
        for cfg, disp_norm, id_norm, _chave in cfgs_norm:
            if id_norm in col_norm or col_norm in disp_norm:
                melhor = cfg["id"]
                break

        # 2) casamento por sinônimo conhecido
        if melhor is None:
            for chave, termos in SYNONYMS.items():
                if any(t in col_norm for t in termos):
                    for cfg, _d, _i, chave_cfg in cfgs_norm:
                        if chave_cfg == chave:
                            melhor = cfg["id"]
                            break
                if melhor:
                    break

        sugestoes[col] = melhor

    return sugestoes


def merge_datasets(df_extraido, df_observado, extraido_col, observado_col, agg="mean"):
    """Junta a série extraída do GEE (coluna `extraido_col`, já mensal) com
    a coluna observada `observado_col` de `df_observado` (que pode ser
    diária ou mensal), agregando o lado observado por mês com a função
    `agg` ('sum' ou 'mean') antes de unir pela data (AAAA-MM). Mantém só os
    meses presentes nos dois lados."""
    if extraido_col not in df_extraido.columns:
        raise ObservedDataError(
            f"A série extraída do GEE está sem a coluna esperada: {extraido_col}"
        )
    if observado_col not in df_observado.columns:
        raise ObservedDataError(
            f"A planilha observada está sem a coluna esperada: {observado_col}"
        )

    obs = df_observado[["ano", "mes", "data", observado_col]].dropna(subset=[observado_col])

    if obs.empty:
        raise ObservedDataError(
            f"A coluna observada '{observado_col}' não tem nenhum valor preenchido."
        )

    obs_mensal = (
        obs.groupby(["ano", "mes", "data"], as_index=False)[observado_col]
        .agg(agg)
        .rename(columns={observado_col: "valor_observado"})
    )

    dados = df_extraido[["data", "ano", "mes", extraido_col]].merge(
        obs_mensal[["data", "valor_observado"]],
        on="data",
        how="inner",
    )

    if dados.empty:
        raise ObservedDataError(
            "Nenhum mês em comum entre os dados extraídos do GEE e os dados "
            "observados. Confira se os períodos das duas fontes se sobrepõem."
        )

    return dados.sort_values("data").reset_index(drop=True)
