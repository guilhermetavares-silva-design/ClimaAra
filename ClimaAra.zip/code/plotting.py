"""Construção dos gráficos de acurácia. Cada função retorna uma
`matplotlib.figure.Figure` (sem `plt.show()`), pronta para ser embutida no
Tkinter via `FigureCanvasTkAgg` ou exportada para PNG com `figure.savefig`.
"""

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

MESES_ABREV = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
                "Jul", "Ago", "Set", "Out", "Nov", "Dez"]


def build_regression_fig(dados, sim_col, obs_col="valor_observado", label="Simulado"):
    x = dados[obs_col].values.reshape(-1, 1)
    y = dados[sim_col].values

    modelo = LinearRegression()
    modelo.fit(x, y)
    y_pred = modelo.predict(x)
    r2 = r2_score(y, y_pred)

    fig, ax = plt.subplots(figsize=(7, 7))

    ax.scatter(dados[obs_col], dados[sim_col], alpha=0.7)
    ax.plot(dados[obs_col], y_pred, color="red", linewidth=2, label="Regressão")

    lim = max(dados[obs_col].max(), dados[sim_col].max())
    ax.plot([0, lim], [0, lim], "--", color="black", label="1:1")

    equacao = (
        f"y = {modelo.coef_[0]:.2f}x + {modelo.intercept_:.2f}\n"
        f"R² = {r2:.3f}"
    )
    ax.text(0.05 * lim, 0.90 * lim, equacao, fontsize=10, bbox=dict(facecolor="white"))

    ax.set_xlabel("Observado")
    ax.set_ylabel(label)
    ax.legend()
    fig.tight_layout()

    return fig


def build_cycle_fig(dados, sim_col, obs_col="valor_observado", label="Simulado"):
    ciclo = dados.groupby("mes")[[obs_col, sim_col]].mean()

    fig, ax = plt.subplots(figsize=(10, 5))

    ax.plot(
        [MESES_ABREV[m - 1] for m in ciclo.index],
        ciclo[obs_col],
        marker="o", linewidth=2, label="Observado",
    )
    ax.plot(
        [MESES_ABREV[m - 1] for m in ciclo.index],
        ciclo[sim_col],
        marker="s", linewidth=2, label=label,
    )

    ax.set_ylabel("Média mensal")
    ax.set_xlabel("Mês")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()

    return fig


def build_residuals_fig(dados, sim_col, obs_col="valor_observado", label="Simulado"):
    dados = dados.copy()
    dados["residuo"] = dados[sim_col] - dados[obs_col]

    fig, ax = plt.subplots(figsize=(10, 5))

    dados.boxplot(column="residuo", by="mes", grid=False, ax=ax)

    ax.axhline(0, linestyle="--", color="red")
    ax.set_title("Distribuição dos resíduos mensais")
    fig.suptitle("")

    ax.set_xlabel("Mês")
    ax.set_ylabel(f"{label} - Observado")
    fig.tight_layout()

    return fig


def build_pbias_fig(dados, sim_col, obs_col="valor_observado", label="Simulado"):
    def pbias_do_ano(grupo):
        return 100 * (grupo[sim_col].sum() - grupo[obs_col].sum()) / grupo[obs_col].sum()

    pbias_anual = (
        dados.groupby("ano")
        .apply(pbias_do_ano, include_groups=False)
        .reset_index(name="PBIAS")
    )

    fig, ax = plt.subplots(figsize=(12, 5))

    ax.bar(pbias_anual["ano"], pbias_anual["PBIAS"])
    ax.axhline(25, color="red", linestyle="--", label="+25%")
    ax.axhline(-25, color="red", linestyle="--", label="-25%")
    ax.axhline(0, color="black")

    ax.set_xlabel("Ano")
    ax.set_ylabel("PBIAS (%)")
    ax.legend()
    fig.tight_layout()

    return fig
