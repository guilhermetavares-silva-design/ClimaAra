"""Executa funções demoradas (chamadas ao Earth Engine) em uma thread separada
sem travar a janela do Tkinter, repassando progresso/erro/resultado de volta
para a thread principal por meio de uma fila.

Uso típico dentro de uma janela Tk:

    def tarefa(progress_cb):
        progress_cb("Fazendo algo...")
        return resultado

    run_in_background(root, tarefa, on_done=..., on_error=..., on_progress=...)
"""

import queue
import threading


def run_in_background(widget, fn, on_done, on_error, on_progress=None, poll_ms=100):
    """Roda `fn(progress_cb)` em background e drena os eventos no widget Tk.

    `widget` precisa suportar `.after(ms, callback)` (qualquer widget Tk serve).
    `on_done(resultado)`, `on_error(excecao)` e `on_progress(mensagem)` são
    sempre chamados na thread principal.
    """
    fila = queue.Queue()

    def progress_cb(mensagem):
        fila.put(("progress", mensagem))

    def alvo():
        try:
            resultado = fn(progress_cb)
        except Exception as exc:  # noqa: BLE001 - repassa qualquer erro para a UI
            fila.put(("error", exc))
        else:
            fila.put(("done", resultado))

    def drenar():
        try:
            tipo, payload = fila.get_nowait()
        except queue.Empty:
            widget.after(poll_ms, drenar)
            return

        if tipo == "progress":
            if on_progress:
                on_progress(payload)
            widget.after(poll_ms, drenar)
        elif tipo == "done":
            on_done(payload)
        elif tipo == "error":
            on_error(payload)

    threading.Thread(target=alvo, daemon=True).start()
    widget.after(poll_ms, drenar)
